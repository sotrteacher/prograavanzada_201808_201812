#include <cstdlib>
#include <iostream>    /*  cout  */
#include <stdio.h>     /* sprintf() */

using namespace std;    /*  cout  */


/**
 * Clase para representar Notas de recordatorio
 * o posiblemente notas de piede de p\'agina. En fin,
 * Una nota que podr\'iamos anotar por ejemplo en un post it.
 * Esta clase tambi\'en muestra como podemos declarar 
 * clases sin secciones privadas. 
 */
struct NOTA{
  int intFecha;
  string stringFecha;
  string stringContenidoDeNota;
  string stringDestinatario;
  string stringRemitente;
  void mostrar(){/* Ejemplo de unb M\'etodo */
    cout<<"Fecha:               "<<stringFecha<<endl;
    cout<<"PARA:"<<stringDestinatario<<endl;
    cout<<"DE:"<<stringRemitente<<endl;
    cout<<stringContenidoDeNota<<endl;
  }
};//end struct NOTA



int main(int argc, char *argv[])
{
    NOTA Nota;
    Nota.intFecha=20180810;
    char str[20];
    sprintf(str,"%d",Nota.intFecha);
    Nota.stringFecha=string(str);
    Nota.stringRemitente="David Helvio";
    Nota.stringDestinatario="John";
    Nota.stringContenidoDeNota="Visto lo visto, sapere aude";
    Nota.mostrar();
    system("PAUSE");
    return EXIT_SUCCESS;
}//end 






